﻿
namespace destek_otomasyonu
{
    partial class Taleplerim
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle1 = new System.Windows.Forms.DataGridViewCellStyle();
            System.Windows.Forms.DataGridViewCellStyle dataGridViewCellStyle2 = new System.Windows.Forms.DataGridViewCellStyle();
            this.dataGridViewAktifTalepler = new System.Windows.Forms.DataGridView();
            this.dataGridViewTamamlanmisTalepler = new System.Windows.Forms.DataGridView();
            this.label1 = new System.Windows.Forms.Label();
            this.label2 = new System.Windows.Forms.Label();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAktifTalepler)).BeginInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTamamlanmisTalepler)).BeginInit();
            this.SuspendLayout();
            // 
            // dataGridViewAktifTalepler
            // 
            this.dataGridViewAktifTalepler.AllowUserToAddRows = false;
            this.dataGridViewAktifTalepler.AllowUserToDeleteRows = false;
            this.dataGridViewAktifTalepler.Anchor = ((System.Windows.Forms.AnchorStyles)(((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewAktifTalepler.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewAktifTalepler.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGridViewAktifTalepler.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewAktifTalepler.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle1.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle1.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle1.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            dataGridViewCellStyle1.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle1.SelectionBackColor = System.Drawing.Color.LightGray;
            dataGridViewCellStyle1.SelectionForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            dataGridViewCellStyle1.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewAktifTalepler.DefaultCellStyle = dataGridViewCellStyle1;
            this.dataGridViewAktifTalepler.GridColor = System.Drawing.SystemColors.Control;
            this.dataGridViewAktifTalepler.Location = new System.Drawing.Point(13, 102);
            this.dataGridViewAktifTalepler.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridViewAktifTalepler.MultiSelect = false;
            this.dataGridViewAktifTalepler.Name = "dataGridViewAktifTalepler";
            this.dataGridViewAktifTalepler.ReadOnly = true;
            this.dataGridViewAktifTalepler.RowHeadersWidth = 51;
            this.dataGridViewAktifTalepler.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewAktifTalepler.Size = new System.Drawing.Size(950, 176);
            this.dataGridViewAktifTalepler.TabIndex = 61;
            // 
            // dataGridViewTamamlanmisTalepler
            // 
            this.dataGridViewTamamlanmisTalepler.AllowUserToAddRows = false;
            this.dataGridViewTamamlanmisTalepler.AllowUserToDeleteRows = false;
            this.dataGridViewTamamlanmisTalepler.Anchor = ((System.Windows.Forms.AnchorStyles)((((System.Windows.Forms.AnchorStyles.Top | System.Windows.Forms.AnchorStyles.Bottom) 
            | System.Windows.Forms.AnchorStyles.Left) 
            | System.Windows.Forms.AnchorStyles.Right)));
            this.dataGridViewTamamlanmisTalepler.AutoSizeColumnsMode = System.Windows.Forms.DataGridViewAutoSizeColumnsMode.Fill;
            this.dataGridViewTamamlanmisTalepler.AutoSizeRowsMode = System.Windows.Forms.DataGridViewAutoSizeRowsMode.AllCells;
            this.dataGridViewTamamlanmisTalepler.BackgroundColor = System.Drawing.Color.White;
            this.dataGridViewTamamlanmisTalepler.ColumnHeadersHeightSizeMode = System.Windows.Forms.DataGridViewColumnHeadersHeightSizeMode.AutoSize;
            dataGridViewCellStyle2.Alignment = System.Windows.Forms.DataGridViewContentAlignment.MiddleCenter;
            dataGridViewCellStyle2.BackColor = System.Drawing.SystemColors.Window;
            dataGridViewCellStyle2.Font = new System.Drawing.Font("Microsoft Sans Serif", 12F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            dataGridViewCellStyle2.ForeColor = System.Drawing.SystemColors.ControlText;
            dataGridViewCellStyle2.SelectionBackColor = System.Drawing.Color.LightGray;
            dataGridViewCellStyle2.SelectionForeColor = System.Drawing.SystemColors.InactiveCaptionText;
            dataGridViewCellStyle2.WrapMode = System.Windows.Forms.DataGridViewTriState.False;
            this.dataGridViewTamamlanmisTalepler.DefaultCellStyle = dataGridViewCellStyle2;
            this.dataGridViewTamamlanmisTalepler.Location = new System.Drawing.Point(13, 413);
            this.dataGridViewTamamlanmisTalepler.Margin = new System.Windows.Forms.Padding(4);
            this.dataGridViewTamamlanmisTalepler.MultiSelect = false;
            this.dataGridViewTamamlanmisTalepler.Name = "dataGridViewTamamlanmisTalepler";
            this.dataGridViewTamamlanmisTalepler.ReadOnly = true;
            this.dataGridViewTamamlanmisTalepler.RowHeadersWidth = 51;
            this.dataGridViewTamamlanmisTalepler.SelectionMode = System.Windows.Forms.DataGridViewSelectionMode.FullRowSelect;
            this.dataGridViewTamamlanmisTalepler.Size = new System.Drawing.Size(950, 182);
            this.dataGridViewTamamlanmisTalepler.TabIndex = 62;
            // 
            // label1
            // 
            this.label1.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label1.AutoSize = true;
            this.label1.Font = new System.Drawing.Font("Calibri", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label1.ForeColor = System.Drawing.Color.OrangeRed;
            this.label1.Location = new System.Drawing.Point(288, 28);
            this.label1.Name = "label1";
            this.label1.Size = new System.Drawing.Size(386, 58);
            this.label1.TabIndex = 63;
            this.label1.Text = "AKTİF TALEPLERİM";
            // 
            // label2
            // 
            this.label2.Anchor = System.Windows.Forms.AnchorStyles.Top;
            this.label2.AutoSize = true;
            this.label2.Font = new System.Drawing.Font("Calibri", 28.2F, System.Drawing.FontStyle.Bold, System.Drawing.GraphicsUnit.Point, ((byte)(162)));
            this.label2.ForeColor = System.Drawing.Color.OrangeRed;
            this.label2.Location = new System.Drawing.Point(154, 322);
            this.label2.Name = "label2";
            this.label2.Size = new System.Drawing.Size(672, 58);
            this.label2.TabIndex = 64;
            this.label2.Text = "SONUÇLANDIRILMIŞ TALEPLERİM";
            // 
            // Taleplerim
            // 
            this.AutoScaleDimensions = new System.Drawing.SizeF(120F, 120F);
            this.AutoScaleMode = System.Windows.Forms.AutoScaleMode.Dpi;
            this.ClientSize = new System.Drawing.Size(976, 624);
            this.Controls.Add(this.label2);
            this.Controls.Add(this.label1);
            this.Controls.Add(this.dataGridViewTamamlanmisTalepler);
            this.Controls.Add(this.dataGridViewAktifTalepler);
            this.FormBorderStyle = System.Windows.Forms.FormBorderStyle.None;
            this.Margin = new System.Windows.Forms.Padding(4);
            this.Name = "Taleplerim";
            this.StartPosition = System.Windows.Forms.FormStartPosition.CenterScreen;
            this.Text = "GirisFormu";
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewAktifTalepler)).EndInit();
            ((System.ComponentModel.ISupportInitialize)(this.dataGridViewTamamlanmisTalepler)).EndInit();
            this.ResumeLayout(false);
            this.PerformLayout();

        }

        #endregion
        private System.Windows.Forms.DataGridView dataGridViewAktifTalepler;
        private System.Windows.Forms.DataGridView dataGridViewTamamlanmisTalepler;
        private System.Windows.Forms.Label label1;
        private System.Windows.Forms.Label label2;
    }
}